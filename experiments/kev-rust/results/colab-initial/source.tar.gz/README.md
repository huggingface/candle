# Kev-0.8B in Rust

Run Jared Palmer's Kev-0.8B using native Candle CPU inference. The executable reads
System One requests as JSONL and returns `choice`, `score`, and `noul` answers.
Python is required once to export the checkpoint and to run the reference validation.
It is not used by the Rust executable.

## Prepare and run

From the Candle repository:

```bash
cd experiments/kev-rust
uv venv --python 3.13
uv pip install --python .venv/bin/python -r requirements.txt
.venv/bin/python scripts/prepare.py
cargo build --release
RAYON_NUM_THREADS=2 target/release/kev-rust --input fixtures/requests.jsonl
```

The exporter downloads pinned base and adapter revisions, checks that every LoRA
tensor was applied, and writes a text-only fp32 checkpoint into `weights/`. Downloads
use the Hugging Face cache. Weights, virtual environments, and build outputs are ignored
by Git. Preserve `metadata.json` alongside the exported weights.

The default runner merges no weights at runtime: it loads the exported backbone and
pointer head, computes the shared state once, and runs each question against its own
copy of the prefix caches. CPU DeltaNet and depthwise convolution use fused Rust loops.
This implementation retains fp32 precision throughout.

Read one request per line from stdin, or use `--input`. Options:

| Option | Behavior |
| --- | --- |
| `--weights DIR` | Exported checkpoint directory, default `weights` |
| `--rows` | Recompute the full state per question (comparison baseline) |
| `--tensor` | Use the original allocating tensor scan and grouped convolution |
| `--repeats N` | Run each request N times with weights already loaded |

Results include answers, calibrated logits, token encodings, inference time,
tokenization time, and actual computed token count for reproducible comparison.
Model loading time is printed to stderr. An invalid request exits with an error;
it is never silently truncated. The command-line runner is not an HTTP server.

The crate also exposes `Runner::load(path, fused)` and `Runner::predict(request, prefix)`
for integration into a Rust application.

## Verify and benchmark

```bash
cargo test --release
.venv/bin/python scripts/validate.py
```

Validation runs the official **unmerged fp32 Python model** and the Rust full-row
and shared-prefix paths sequentially. It checks identical tokenization, option order,
raw probabilities, decisions, question isolation, and chunked cache continuation.
Independent kernel tests compare the fused CPU scan and depthwise convolution with
tensor implementations. Benchmark repeats exclude each request's first iteration.

The report is saved as `results/report.json`; individual parity summaries are retained
in `results/`. Full prediction JSONL files are local artifacts and ignored by Git.
These fixtures test implementation parity, not general model accuracy or calibration.

## Current scope

CPU fp32 inference for the released Qwen3.5-based Kev-0.8B. CUDA, Metal, quantization,
HTTP serving, and a cross-request prefix cache are not implemented. Long contexts use
chunked state prefill; the 64k admission limit does not establish 64k accuracy or latency.
Performance results apply only to the hardware and fixture set recorded in the report.

[RESEARCH.md](RESEARCH.md) records the architecture, sources, pins, comparison rule,
and optimization choices. [THIRD_PARTY.md](THIRD_PARTY.md) records source attribution.
